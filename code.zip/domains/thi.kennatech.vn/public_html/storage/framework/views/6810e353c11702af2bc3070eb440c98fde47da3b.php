<textarea class="form-control richTextBox" name="<?php echo e($row->field); ?>" id="richtext<?php echo e($row->field); ?>">
  <?php echo e(old($row->field, $dataTypeContent->{$row->field} ?? '')); ?>

</textarea>



<?php $__env->startPush('javascript'); ?>
  <script>
    $(document).ready(function() {
      var additionalConfig = {
        selector: 'textarea.richTextBox[name="<?php echo e($row->field); ?>"]',
      }

      $.extend(additionalConfig, <?php echo json_encode($options->tinymceOptions ?? (object) []); ?>)

      const oldConfig = window.voyagerTinyMCE.getConfig(additionalConfig)

      const config = {
        ...oldConfig,
        codesample_global_prismjs: true,
        base_url: '<?php echo e(url('/asset/js/tinymce')); ?>',
        plugins: oldConfig.plugins + ' codesample',
        toolbar: oldConfig.toolbar + `| codesample`,
        entity_encoding: 'raw',
        verify_html: false,
        height: 300,
        min_height: 300,
      }

      tinymce.init(config);
    });
  </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/thi/domains/thi.kennatech.vn/public_html/resources/views/vendor/voyager/formfields/rich_text_box.blade.php ENDPATH**/ ?>